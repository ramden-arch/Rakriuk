package id.rakriuk.pos;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Build;
import android.util.Base64;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

/** Printer thermal Bluetooth klasik (SPP/RFCOMM): daftar perangkat yang sudah dipasangkan, sambung, kirim byte. */
@CapacitorPlugin(
    name = "Spp",
    permissions = { @Permission(alias = "bt", strings = { Manifest.permission.BLUETOOTH_CONNECT }) }
)
public class SppPlugin extends Plugin {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothSocket socket;
    private OutputStream out;

    private boolean needPerm() {
        return Build.VERSION.SDK_INT >= 31 && getPermissionState("bt") != PermissionState.GRANTED;
    }

    @PluginMethod
    public void list(PluginCall call) {
        if (needPerm()) {
            requestPermissionForAlias("bt", call, "permCb");
            return;
        }
        doList(call);
    }

    @PermissionCallback
    private void permCb(PluginCall call) {
        if (needPerm()) {
            call.reject("Izin Bluetooth ditolak");
        } else {
            doList(call);
        }
    }

    @SuppressLint("MissingPermission")
    private void doList(PluginCall call) {
        BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
        if (a == null) {
            call.reject("Bluetooth tidak tersedia");
            return;
        }
        if (!a.isEnabled()) {
            call.reject("Bluetooth mati, aktifkan dulu");
            return;
        }
        JSArray arr = new JSArray();
        for (BluetoothDevice d : a.getBondedDevices()) {
            JSObject o = new JSObject();
            o.put("name", d.getName());
            o.put("address", d.getAddress());
            arr.put(o);
        }
        JSObject r = new JSObject();
        r.put("devices", arr);
        call.resolve(r);
    }

    @PluginMethod
    public void connect(final PluginCall call) {
        final String addr = call.getString("address");
        if (addr == null) {
            call.reject("Alamat printer kosong");
            return;
        }
        if (needPerm()) {
            call.reject("Izin Bluetooth belum diberikan");
            return;
        }
        new Thread(new Runnable() {
            @SuppressLint("MissingPermission")
            @Override
            public void run() {
                try {
                    closeQuiet();
                    BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                    if (a == null || !a.isEnabled()) throw new IOException("Bluetooth mati");
                    BluetoothDevice d = a.getRemoteDevice(addr);
                    a.cancelDiscovery();
                    socket = d.createRfcommSocketToServiceRecord(SPP);
                    socket.connect();
                    out = socket.getOutputStream();
                    call.resolve();
                } catch (Exception e) {
                    closeQuiet();
                    call.reject("Gagal terhubung: " + e.getMessage());
                }
            }
        }).start();
    }

    @PluginMethod
    public void write(final PluginCall call) {
        final String data = call.getString("data");
        if (data == null) {
            call.reject("Data kosong");
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (out == null) throw new IOException("Printer belum terhubung");
                    byte[] b = Base64.decode(data, Base64.DEFAULT);
                    out.write(b);
                    out.flush();
                    call.resolve();
                } catch (Exception e) {
                    call.reject("Gagal kirim: " + e.getMessage());
                }
            }
        }).start();
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        closeQuiet();
        call.resolve();
    }

    private void closeQuiet() {
        try { if (out != null) out.close(); } catch (Exception e) { }
        try { if (socket != null) socket.close(); } catch (Exception e) { }
        out = null;
        socket = null;
    }

    @Override
    protected void handleOnDestroy() {
        closeQuiet();
    }
}
