# Rakriuk POS — Build APK lewat GitHub

## Upload
1. Buat repository baru di GitHub.
2. Upload **seluruh isi folder `rakriuk-pos-apk`**, termasuk folder tersembunyi `.github`.
3. Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.

## Build APK
- Buka repository → **Actions** → **Build APK** → **Run workflow**.
- Pada `Nama aplikasi di HP`, isi misalnya `Rakriuk POS`.
- Tunggu workflow selesai.
- Buka hasil workflow → **Artifacts** → `rakriuk-pos-apk`.
- Ekstrak artifact dan ambil `app-debug.apk`.

Workflow juga otomatis berjalan saat push ke branch `main` atau `master`.

## Catatan
- APK yang dihasilkan adalah **debug APK** dan cocok untuk pengujian/pemakaian internal.
- Untuk Google Play, gunakan build release/AAB dengan signing key sendiri.
- Jika build gagal pada printer Bluetooth klasik (SPP), ubah `WITH_SPP: "1"` menjadi `WITH_SPP: "0"` di `.github/workflows/build-apk.yml`, lalu jalankan lagi.
