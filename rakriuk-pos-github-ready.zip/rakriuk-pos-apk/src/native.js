// Jembatan native untuk aplikasi kasir (hanya aktif di dalam aplikasi Android).
// WebView Android tidak punya Web Bluetooth / BarcodeDetector / pemilih kontak,
// jadi semuanya dialihkan ke plugin Capacitor lewat window.RKN.
import { Capacitor, registerPlugin } from "@capacitor/core";
import { App } from "@capacitor/app";
import { BleClient } from "@capacitor-community/bluetooth-le";
import { BarcodeScanner } from "@capacitor-mlkit/barcode-scanning";
import { Contacts } from "@capacitor-community/contacts";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import { LocalNotifications } from "@capacitor/local-notifications";

if (Capacitor.isNativePlatform()) {
  const Spp = registerPlugin("Spp"); // plugin Java lokal (Bluetooth klasik / SPP)
  const SV = [
    "000018f0-0000-1000-8000-00805f9b34fb",
    "0000ff00-0000-1000-8000-00805f9b34fb",
    "e7810a71-73ae-499d-8c15-faa9aef0c3f2",
    "49535343-fe7d-4ae5-8fa9-9fafd205e455",
    "0000ffe0-0000-1000-8000-00805f9b34fb",
    "0000fff0-0000-1000-8000-00805f9b34fb",
  ];
  let dev = null, svc = null, chr = null, noresp = false, chDone = false;

  const b64 = (bytes) => {
    const u = new Uint8Array(bytes);
    let s = "";
    for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192));
    return btoa(s);
  };

  window.RKN = {
    spp: {
      list: async () => (await Spp.list()).devices || [],
      connect: (address) => Spp.connect({ address }),
      write: (bytes) => Spp.write({ data: b64(bytes) }),
    },
    ble: {
      connect: async (prefixes) => {
        await BleClient.initialize();
        const o = { optionalServices: SV };
        if (prefixes && prefixes.length === 1) o.namePrefix = prefixes[0];
        const d = await BleClient.requestDevice(o);
        await BleClient.connect(d.deviceId, () => { dev = null; });
        const services = await BleClient.getServices(d.deviceId);
        for (const s of services) {
          for (const c of s.characteristics) {
            if (c.properties.write || c.properties.writeWithoutResponse) {
              dev = d.deviceId; svc = s.uuid; chr = c.uuid; noresp = !!c.properties.writeWithoutResponse;
              return d.name || "Printer BLE";
            }
          }
        }
        throw new Error("Karakteristik tulis tidak ditemukan");
      },
      write: async (bytes) => {
        if (!dev) throw new Error("Printer belum terhubung");
        const v = new DataView(new Uint8Array(bytes).buffer);
        if (noresp) await BleClient.writeWithoutResponse(dev, svc, chr, v);
        else await BleClient.write(dev, svc, chr, v);
      },
    },
    scan: async () => {
      const s = await BarcodeScanner.isSupported();
      if (!s.supported) throw new Error("Scanner barcode tidak didukung di perangkat ini");
      const p = await BarcodeScanner.requestPermissions();
      if (p.camera !== "granted" && p.camera !== "limited") throw new Error("Izin kamera ditolak");
      try {
        const a = await BarcodeScanner.isGoogleBarcodeScannerModuleAvailable();
        if (!a.available) {
          await BarcodeScanner.installGoogleBarcodeScannerModule();
          throw new Error("Modul scanner Google sedang diunduh, coba lagi beberapa saat lagi");
        }
      } catch (e) {
        if (String(e.message || e).includes("diunduh")) throw e;
      }
      const r = await BarcodeScanner.scan();
      return r.barcodes && r.barcodes[0] ? r.barcodes[0].rawValue : "";
    },
    contacts: async () => {
      const p = await Contacts.requestPermissions();
      const g = p && (p.contacts || p.readContacts);
      if (g !== undefined && g !== "granted") throw new Error("Izin kontak ditolak. Aktifkan di Pengaturan HP → Aplikasi → aplikasi kasir ini → Izin → Kontak.");
      const r = await Contacts.getContacts({ projection: { name: true, phones: true } });
      return (r.contacts || []).map((c) => ({
        n: (c.name && (c.name.display || [c.name.given, c.name.family].filter(Boolean).join(" "))) || "",
        nums: (c.phones || []).map((ph) => ph.number).filter(Boolean),
      })).filter((c) => c.nums.length);
    },
    saveContacts: async (list) => {
      const p = await Contacts.requestPermissions();
      const g = p && (p.contacts || p.writeContacts || p.readContacts);
      if (g !== undefined && g !== "granted") throw new Error("Izin kontak ditolak. Aktifkan di Pengaturan HP → Aplikasi → aplikasi kasir ini → Izin → Kontak.");
      const norm = (t) => String(t || "").replace(/\D/g, "").replace(/^0/, "62");
      const ex = await Contacts.getContacts({ projection: { phones: true } });
      const have = new Set();
      (ex.contacts || []).forEach((c) => (c.phones || []).forEach((ph) => have.add(norm(ph.number))));
      let n = 0;
      for (const c of list) {
        const d = norm(c.t);
        if (!d || have.has(d)) continue;
        await Contacts.createContact({ contact: { name: { given: c.n }, phones: [{ type: "mobile", number: c.t }] } });
        have.add(d); n++;
      }
      return n;
    },
    save: async (name, data) => {
      const r = await Filesystem.writeFile({ path: name, data, directory: Directory.Cache, encoding: Encoding.UTF8 });
      await Share.share({ title: name, url: r.uri, dialogTitle: "Simpan / bagikan " + name });
    },
    notifyInit: async () => {
      try {
        let p = await LocalNotifications.checkPermissions();
        if (p.display !== "granted") p = await LocalNotifications.requestPermissions();
        if (p.display !== "granted") return false;
        if (!chDone) {
          await LocalNotifications.createChannel({ id: "pesanan", name: "Pesanan baru", description: "Pesanan online dan status pesanan", importance: 5, visibility: 1, vibration: true });
          chDone = true;
        }
        return true;
      } catch (e) { return false; }
    },
    notify: async (m, v, t) => {
      try {
        if (!(await window.RKN.notifyInit())) return;
        await LocalNotifications.schedule({ notifications: [{ id: Date.now() % 2147483647, title: t || "Rakriuk POS", body: m, channelId: "pesanan", extra: { view: v || "pesanan" } }] });
      } catch (e) {}
    },
    exit: () => App.exitApp(),
  };
  // ketuk notifikasi -> buka menu tujuan (Pesanan)
  LocalNotifications.addListener("localNotificationActionPerformed", (e) => {
    const v = (e.notification && e.notification.extra && e.notification.extra.view) || "pesanan";
    window.RKN_open ? window.RKN_open(v) : (window.__pv = v);
  });
  App.addListener("backButton", () => { window.RKN_back ? window.RKN_back() : App.exitApp(); });
}
