// Dijalankan setelah `cap add android`: izin, plugin Bluetooth klasik (Java), ikon.
import fs from "fs";
import path from "path";

const A = "android";
const WITH_SPP = process.env.WITH_SPP !== "0";
const pkgDir = path.join(A, "app/src/main/java/id/rakriuk/pos");
const res = path.join(A, "app/src/main/res");

// 1) izin & fitur di AndroidManifest
const mf = path.join(A, "app/src/main/AndroidManifest.xml");
let m = fs.readFileSync(mf, "utf8");
// Capacitor memvalidasi izin yang dideklarasikan tiap plugin; plugin kontak memerlukan READ dan WRITE.
const perms = ["BLUETOOTH", "BLUETOOTH_ADMIN", "BLUETOOTH_CONNECT", "CAMERA", "READ_CONTACTS", "WRITE_CONTACTS", "POST_NOTIFICATIONS"];
for (const p of perms) {
  const line = `android.permission.${p}`;
  if (!m.includes(`android:name="${line}"`)) m = m.replace("</manifest>", `    <uses-permission android:name="${line}" />\n</manifest>`);
}
for (const f of ["android.hardware.bluetooth_le", "android.hardware.camera"]) {
  if (!m.includes(`android:name="${f}"`)) m = m.replace("</manifest>", `    <uses-feature android:name="${f}" android:required="false" />\n</manifest>`);
}
fs.writeFileSync(mf, m);

// 2) plugin Java Bluetooth klasik (SPP) + MainActivity
if (WITH_SPP) {
  fs.mkdirSync(pkgDir, { recursive: true });
  fs.copyFileSync("native/SppPlugin.java", path.join(pkgDir, "SppPlugin.java"));
  fs.copyFileSync("native/MainActivity.java", path.join(pkgDir, "MainActivity.java"));
}

// 3) ikon aplikasi
function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    e.isDirectory() ? copyDir(s, d) : fs.copyFileSync(s, d);
  }
}
copyDir("resources/android", res);
fs.mkdirSync(path.join(res, "values"), { recursive: true });
fs.writeFileSync(path.join(res, "values/ic_launcher_background.xml"),
  '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#E8530E</color>\n</resources>\n');
console.log("Patch Android selesai (SPP: " + WITH_SPP + ")");
