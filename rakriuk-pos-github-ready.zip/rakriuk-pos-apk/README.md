# Rakriuk POS — proyek APK (Android)

Aplikasi kasir Rakriuk POS dibungkus dengan Capacitor. Seluruh halaman kasir ada di `www/index.html`,
jadi aplikasi **jalan penuh offline**. Fungsi yang tidak ada di WebView Android dialihkan ke plugin native:

| Fitur | Di APK |
|---|---|
| Printer thermal Bluetooth | Bluetooth klasik (SPP) lewat plugin `native/SppPlugin.java` (printer yang sudah dipasangkan), plus BLE sebagai cadangan |
| Scan barcode kamera | ML Kit Barcode Scanning |
| Impor kontak HP | Semua kontak dibaca (izin Kontak), lalu pilih kontak dan nomor yang diimpor (kontak dengan beberapa nomor: pilih satu nomor atau semua). Pelanggan juga bisa disimpan balik ke kontak HP |
| Ekspor laporan / backup / website order | Lewat menu Bagikan Android (Simpan ke File, Drive, WhatsApp, dll.) |
| Notifikasi pesanan baru | Notifikasi lokal Android (saluran "Pesanan baru"); ketuk notifikasi membuka menu Pesanan. Izin diminta setelah login; uji lewat Setelan → Lainnya → Tes notifikasi |
| Tombol kembali | Tutup modal → tutup menu → ke Kasir → keluar |
| Backup & pulihkan data | Setelan → Lainnya → Backup / Pulihkan (.json) |

## Cara paling mudah: build APK di GitHub (tanpa Android Studio)

1. Buat repo baru di GitHub (boleh private), unggah **isi folder ini** (termasuk folder `.github`).
2. Buka tab **Actions** → **Build APK** → **Run workflow**. Isi **Nama aplikasi** (label ikon di HP, default "Rakriuk POS"). Tunggu sekitar 5–10 menit.
3. Unduh artifact **rakriuk-pos-apk** (berisi `app-debug.apk`).
4. Salin ke HP, buka, izinkan "pasang dari sumber tidak dikenal", pasang.

APK ini ditandatangani dengan kunci debug: cukup untuk dipakai sendiri / dibagikan ke karyawan.
Untuk Google Play butuh AAB yang ditandatangani kunci rilis (Android Studio → Build → Generate Signed Bundle / APK).

## Build di komputer sendiri

Kebutuhan: Node 20, JDK 17, Android Studio (SDK terpasang).

```bash
npm install
npm run build:web
npx cap add android
node scripts/patch-android.mjs      # izin, plugin printer, ikon
npx cap sync android
cd android && ./gradlew assembleDebug
# hasil: android/app/build/outputs/apk/debug/app-debug.apk
```

Setelah mengubah `www/index.html`: `npm run android:sync` lalu build ulang.

## Memakai printer

1. Nyalakan printer, pasangkan (pair) di **Pengaturan → Bluetooth** HP (PIN biasanya `0000` atau `1234`).
2. Di aplikasi: menu **Printer → Hubungkan** → pilih printer. Aplikasi mengingat printer terakhir dan
   menyambung ulang otomatis saat mencetak.
3. Printer label (Xprinter, Gprinter, TSC): pilih bahasa **TSPL** di Printer → Printer label & barcode.

## Catatan penting

- **Mode lokal atau cloud.** Tanpa server, data tersimpan di HP (buat Backup berkala). Dengan **Rakriuk Cloud Server**
  (zip terpisah), isi alamat server `https://…` di layar awal: akun email owner/karyawan, kode akses, sinkron, dan pantau
  jarak jauh aktif. Server harus HTTPS.
- Akun owner/karyawan dan outlet tersimpan lokal di HP; login tetap bisa saat offline.
- Jika build gagal di langkah plugin Bluetooth klasik, ubah `WITH_SPP: "0"` di `.github/workflows/build-apk.yml`
  (printer BLE tetap bisa dipakai), lalu kirim log error-nya untuk diperbaiki.
- Jika `npm install` gagal karena versi plugin, kirim log-nya; versi plugin tinggal disesuaikan di `package.json`.

- Notifikasi hanya muncul saat aplikasi sedang berjalan (terbuka atau di latar belakang singkat). Notifikasi saat aplikasi benar-benar tertutup memerlukan push (Firebase) dari server.

- **Teks di top bar** dan judul notifikasi diatur di aplikasi: Setelan → Profil → "Teks di top bar" (kosong = nama menu). Nama label ikon diisi saat menjalankan workflow.
